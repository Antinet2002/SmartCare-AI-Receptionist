import logging
import os
from datetime import datetime

import openai
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

log = logging.getLogger("ai_service")

MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
api_key = (os.getenv("OPENAI_API_KEY") or "").strip()
if api_key == "YOUR_OPENAI_API_KEY":
    api_key = ""

client = OpenAI(api_key=api_key, timeout=30.0, max_retries=2) if api_key else None

SYSTEM_PROMPT = """
You are an intelligent AI receptionist for SmartCare Solutions.

Responsibilities:
1. Greet customers politely.
2. Answer basic company questions.
3. Help customers understand available services.
4. Help with appointment booking.
5. Ask for missing information when needed.
6. Never invent company information.
7. Keep responses concise and professional.
8. If you cannot answer something, recommend contacting a human receptionist.
9. You cannot book appointments yourself in chat. Tell the customer to use
   the "Book Appointment" form on this page.

Company:
Name: SmartCare Solutions

Working Hours:
Monday-Friday: 9:00 AM - 6:00 PM
Saturday: 10:00 AM - 2:00 PM
Sunday: Closed

Services:
- General Consultation
- Business Consultation
- Technical Support
- Product Demonstration
"""


class AIServiceError(Exception):
    """Error with a safe message for the user and an HTTP status code."""

    def __init__(self, user_message, status=500):
        super().__init__(user_message)
        self.user_message = user_message
        self.status = status


def _clean_history(history, limit=10):
    """Accept only well-formed user/assistant turns from the browser."""
    cleaned = []
    for item in (history or [])[-limit:]:
        if not isinstance(item, dict):
            continue
        role, content = item.get("role"), item.get("content")
        if role in ("user", "assistant") and isinstance(content, str) and content.strip():
            cleaned.append({"role": role, "content": content[:2000]})
    return cleaned


def get_ai_response(message, conversation_history=None):
    if not client:
        raise AIServiceError(
            "AI is not configured yet. Add a valid OPENAI_API_KEY to the .env file "
            "and restart the server.",
            503,
        )

    system = SYSTEM_PROMPT + f"\nToday's date: {datetime.now():%A, %d %B %Y}\n"
    messages = [{"role": "system", "content": system}]
    messages.extend(_clean_history(conversation_history))
    messages.append({"role": "user", "content": message})

    try:
        response = client.chat.completions.create(
            model=MODEL, messages=messages, temperature=0.4
        )
    except openai.AuthenticationError:
        log.error("OpenAI 401: API key is invalid or revoked")
        raise AIServiceError("The AI key is invalid. Please contact the administrator.", 502)
    except openai.RateLimitError as e:
        # Covers both "too many requests" and "insufficient_quota" (no billing credit)
        log.error("OpenAI 429: %s", e)
        raise AIServiceError(
            "The AI service is busy or out of credit. Please try again shortly.", 503
        )
    except openai.NotFoundError as e:
        log.error("OpenAI 404 (wrong model name '%s'?): %s", MODEL, e)
        raise AIServiceError("The AI model is not available. Please contact the administrator.", 502)
    except openai.APITimeoutError:
        log.error("OpenAI request timed out")
        raise AIServiceError("The AI took too long to respond. Please try again.", 504)
    except openai.APIConnectionError as e:
        log.error("OpenAI connection error: %s", e)
        raise AIServiceError("Could not reach the AI service. Check the internet connection.", 503)
    except openai.APIError as e:
        log.error("OpenAI API error: %s", e)
        raise AIServiceError("The AI service returned an error. Please try again.", 502)

    text = (response.choices[0].message.content or "").strip()
    return text or "Sorry, I couldn't come up with a reply. Could you rephrase that?"
