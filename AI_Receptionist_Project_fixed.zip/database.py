import os
import sqlite3
from datetime import datetime

# Absolute path: DB is always next to this file, no matter where you run `python` from
DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "receptionist.db")


class SlotTakenError(Exception):
    pass


def get_connection():
    conn = sqlite3.connect(DATABASE, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            created_at TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            appointment_date TEXT NOT NULL,
            appointment_time TEXT NOT NULL,
            service TEXT,
            status TEXT DEFAULT 'Booked',
            created_at TEXT
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT,
            user_message TEXT,
            ai_response TEXT,
            created_at TEXT
        )
    """)

    # The database itself now refuses two 'Booked' rows for the same slot,
    # so two people clicking at the same moment can't double-book.
    try:
        cursor.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS uniq_booked_slot
            ON appointments (appointment_date, appointment_time)
            WHERE status = 'Booked'
        """)
    except sqlite3.IntegrityError:
        print("WARNING: existing duplicate bookings found; unique-slot index not created. "
              "Clean up duplicates in receptionist.db and restart.")

    conn.commit()
    conn.close()


def book_appointment(name, phone, email, date, time, service):
    """Save customer (once) + appointment in ONE transaction.
    Raises SlotTakenError if the slot is already booked."""
    conn = get_connection()
    try:
        with conn:  # commits on success, rolls back on error
            existing = conn.execute(
                "SELECT id FROM appointments WHERE appointment_date=? "
                "AND appointment_time=? AND status='Booked'", (date, time)
            ).fetchone()
            if existing:
                raise SlotTakenError()

            customer = None
            if phone:
                customer = conn.execute(
                    "SELECT id FROM customers WHERE phone=?", (phone,)).fetchone()
            if not customer and email:
                customer = conn.execute(
                    "SELECT id FROM customers WHERE email=?", (email,)).fetchone()
            if not customer:
                conn.execute(
                    "INSERT INTO customers (name, phone, email, created_at) VALUES (?,?,?,?)",
                    (name, phone, email, datetime.now().isoformat()),
                )

            conn.execute(
                """INSERT INTO appointments
                   (customer_name, phone, email, appointment_date,
                    appointment_time, service, status, created_at)
                   VALUES (?,?,?,?,?,?, 'Booked', ?)""",
                (name, phone, email, date, time, service, datetime.now().isoformat()),
            )
    except sqlite3.IntegrityError:
        raise SlotTakenError()
    finally:
        conn.close()


def get_appointments():
    conn = get_connection()
    try:
        return conn.execute("""
            SELECT * FROM appointments
            ORDER BY appointment_date, appointment_time
        """).fetchall()
    finally:
        conn.close()


def save_conversation(name, user_message, ai_response):
    conn = get_connection()
    try:
        with conn:
            conn.execute(
                """INSERT INTO conversations
                   (customer_name, user_message, ai_response, created_at)
                   VALUES (?, ?, ?, ?)""",
                (name, user_message, ai_response, datetime.now().isoformat()),
            )
    finally:
        conn.close()
