# AI-Powered Virtual Receptionist

A Flask-based AI receptionist with:
- AI chat
- Voice input using browser Web Speech API
- Text-to-speech
- Appointment booking
- Duplicate-slot validation
- Customer database
- Conversation logging
- Admin appointment dashboard

## 1. Install Python

Python 3.10+ is recommended.

## 2. Create virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

## 3. Install dependencies

```bash
pip install -r requirements.txt
```

## 4. Configure API key

Copy `.env.example` to `.env`:

```text
OPENAI_API_KEY=YOUR_OPENAI_API_KEY
```

Optional settings in `.env`: `OPENAI_MODEL` (default `gpt-4o-mini`) and
`ADMIN_PASSWORD` (protects `/admin`, username `admin`).

Never commit `.env` to GitHub. Restart the server after editing `.env`.

## 5. Run

```bash
python app.py
```

Open:

http://127.0.0.1:5000

Admin dashboard:

http://127.0.0.1:5000/admin

## Project structure

ai-receptionist/
├── app.py
├── database.py
├── ai_service.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   ├── index.html
│   └── admin.html
└── static/
    ├── style.css
    └── script.js
