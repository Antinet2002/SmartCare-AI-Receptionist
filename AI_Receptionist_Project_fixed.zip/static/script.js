// Conversation memory sent to the server so the AI remembers earlier messages
const history = [];
let sending = false;

// Safe JSON reader: never throws if the server sends an HTML error page
async function readJson(response) {
    try {
        return await response.json();
    } catch {
        return {};
    }
}

async function sendMessage() {
    if (sending) return;

    const input = document.getElementById("message");
    const message = input.value.trim();
    if (!message) return;

    addMessage(message, "user");
    input.value = "";

    sending = true;
    const sendBtn = document.getElementById("sendBtn");
    sendBtn.disabled = true;
    const typing = addMessage("Typing...", "bot");

    try {
        const response = await fetch("/api/chat", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                message: message,
                name: document.getElementById("name").value.trim() || "Guest",
                history: history.slice(-10)
            })
        });

        const data = await readJson(response);
        const reply = data.response || "Sorry, something went wrong. Please try again.";

        typing.innerText = reply;
        speak(reply);

        if (response.ok) {
            history.push({role: "user", content: message});
            history.push({role: "assistant", content: reply});
        }
    } catch (error) {
        typing.innerText = "Cannot reach the server. Is it running?";
    } finally {
        sending = false;
        sendBtn.disabled = false;
        input.focus();
    }
}

function addMessage(text, sender) {
    const chat = document.getElementById("chat");
    const div = document.createElement("div");

    div.className = `${sender} message`;
    div.innerText = text;

    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
    return div;
}

async function bookAppointment() {
    const result = document.getElementById("bookingResult");
    const data = {
        name: document.getElementById("name").value.trim(),
        phone: document.getElementById("phone").value.trim(),
        email: document.getElementById("email").value.trim(),
        service: document.getElementById("service").value,
        date: document.getElementById("date").value,
        time: document.getElementById("time").value
    };

    if (!data.name || !data.date || !data.time) {
        result.innerText = "Please enter your name, date and time.";
        return;
    }

    try {
        const response = await fetch("/api/book", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(data)
        });

        const body = await readJson(response);
        result.innerText = body.message || "Unable to book the appointment.";

        if (body.success) {
            speak("Your appointment has been successfully booked.");
        }
    } catch (error) {
        result.innerText = "Cannot reach the server. Is it running?";
    }
}

function startVoice() {
    const SpeechRecognition =
        window.SpeechRecognition ||
        window.webkitSpeechRecognition;

    if (!SpeechRecognition) {
        alert("Speech recognition is not supported in this browser. Try Chrome or Edge.");
        return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-IN";
    recognition.interimResults = false;

    recognition.onresult = function(event) {
        document.getElementById("message").value = event.results[0][0].transcript;
        sendMessage();
    };

    recognition.onerror = function(event) {
        const reasons = {
            "not-allowed": "Microphone permission was blocked. Allow it in the browser address bar.",
            "service-not-allowed": "Microphone permission was blocked.",
            "no-speech": "I didn't hear anything. Please try again.",
            "network": "Voice recognition needs an internet connection."
        };
        addMessage(reasons[event.error] || `Voice error: ${event.error}`, "bot");
    };

    recognition.start();
}

function speak(text) {
    if (!("speechSynthesis" in window)) return;

    window.speechSynthesis.cancel();

    const speech = new SpeechSynthesisUtterance(text);
    speech.lang = "en-IN";
    speech.rate = 1;
    speech.pitch = 1;

    window.speechSynthesis.speak(speech);
}

// Don't allow picking past dates in the date picker
document.getElementById("date").min = new Date().toLocaleDateString("en-CA");

document.getElementById("message").addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        event.preventDefault();
        sendMessage();
    }
});
