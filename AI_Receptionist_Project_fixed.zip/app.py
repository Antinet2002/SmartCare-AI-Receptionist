import logging
import os
import re
from datetime import datetime, date as date_cls, time as time_cls
from functools import wraps

from dotenv import load_dotenv
from flask import Flask, render_template, request, jsonify, Response

from database import init_db, book_appointment, get_appointments, save_conversation, SlotTakenError
from ai_service import get_ai_response, AIServiceError

load_dotenv()
logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
init_db()

# weekday(): Monday=0 ... Sunday=6 -> (opens, closes)
WORKING_HOURS = {
    **{d: (time_cls(9, 0), time_cls(18, 0)) for d in range(0, 5)},
    5: (time_cls(10, 0), time_cls(14, 0)),
}
SERVICES = {
    "General Consultation", "Business Consultation",
    "Technical Support", "Product Demonstration",
}


def admin_required(view):
    """If ADMIN_PASSWORD is set in .env, protect the dashboard with a password."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        password = os.getenv("ADMIN_PASSWORD")
        if password:
            auth = request.authorization
            if not auth or auth.username != "admin" or auth.password != password:
                return Response("Login required", 401,
                                {"WWW-Authenticate": 'Basic realm="Admin"'})
        return view(*args, **kwargs)
    return wrapper


def json_body():
    # silent=True: never crashes with 415/400 HTML pages on bad/missing JSON
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def clean(value, max_len=200):
    return str(value).strip()[:max_len] if value is not None else ""


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/admin")
@admin_required
def admin():
    return render_template("admin.html", appointments=get_appointments())


@app.route("/api/chat", methods=["POST"])
def chat():
    data = json_body()
    message = clean(data.get("message"), 1000)
    name = clean(data.get("name"), 100) or "Guest"

    if not message:
        return jsonify({"response": "Please enter a message."}), 400

    try:
        response = get_ai_response(message, data.get("history"))
    except AIServiceError as e:
        return jsonify({"response": e.user_message}), e.status
    except Exception:
        app.logger.exception("Unexpected chat error")
        return jsonify({"response": "Sorry, something went wrong on our side."}), 500

    try:
        save_conversation(name, message, response)
    except Exception:
        # A logging failure must not hide a good AI answer from the customer
        app.logger.exception("Could not save conversation")

    return jsonify({"response": response})


def validate_slot(date_str, time_str):
    """Return (date, time, error_message)."""
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d").date()
        t = datetime.strptime(time_str, "%H:%M").time()
    except ValueError:
        return None, None, "Invalid date or time format."

    now = datetime.now()
    if datetime.combine(d, t) <= now:
        return None, None, "Please choose a future date and time."

    hours = WORKING_HOURS.get(d.weekday())
    if not hours:
        return None, None, "We are closed on Sundays. Please pick another day."
    opens, closes = hours
    if not (opens <= t < closes):
        return None, None, (
            f"Working hours that day are {opens:%I:%M %p} - {closes:%I:%M %p}."
        )
    return d, t, None


@app.route("/api/book", methods=["POST"])
def book():
    data = json_body()

    name = clean(data.get("name"), 100)
    phone = clean(data.get("phone"), 30)
    email = clean(data.get("email"), 120)
    date = clean(data.get("date"), 10)
    time = clean(data.get("time"), 5)
    service = clean(data.get("service"), 60)

    if not name or not date or not time:
        return jsonify({"success": False,
                        "message": "Name, date and time are required."}), 400

    if phone and not re.fullmatch(r"[+\d][\d\s\-()]{6,19}", phone):
        return jsonify({"success": False, "message": "Please enter a valid phone number."}), 400
    if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        return jsonify({"success": False, "message": "Please enter a valid email."}), 400
    if service and service not in SERVICES:
        return jsonify({"success": False, "message": "Please choose a valid service."}), 400

    _, _, error = validate_slot(date, time)
    if error:
        return jsonify({"success": False, "message": error}), 400

    try:
        book_appointment(name, phone, email, date, time, service)
    except SlotTakenError:
        return jsonify({"success": False,
                        "message": "This appointment slot is already booked."}), 409
    except Exception:
        app.logger.exception("Booking failed")
        return jsonify({"success": False,
                        "message": "Could not save the appointment. Please try again."}), 500

    return jsonify({"success": True,
                    "message": f"Appointment successfully booked for {name}."})


@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"message": "Not found"}), 404
    return e


@app.errorhandler(500)
def server_error(e):
    if request.path.startswith("/api/"):
        return jsonify({"response": "Server error.", "message": "Server error."}), 500
    return e


if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG", "1") == "1", host="127.0.0.1", port=5000)
